$(document).ready(function() {
    $('.main__play').click(function(event) {
        $(this).toggleClass('active');
        if ($(this).hasClass('active')) {
            swiper.autoplay.stop(); // Stop autoplay if active
        } else {
            swiper.autoplay.start(); // Start autoplay if not active
        }
    })
    $('.qa__dropdown_question').click(function(event) {
        $(this).parent('.qa__dropdown').toggleClass('active');
    })
})

// SWIPER
var swiper = new Swiper('.main__swiper', {
    slidesPerView: 1,
    loop: true,
    autoplay: {
        delay: 2500,
        disableOnInteraction: false,
    },
});
var keySwiper = new Swiper('.key__swiper', {
    slidesPerView: 7,
    spaceBetween: 16,
    navigation: {
        nextEl: '.key__arrow-right',
        prevEl: '.key__arrow-left',
    },
});
var newsSwiper = new Swiper('.news__swiper', {
    slidesPerView: 4,
    spaceBetween: 16,
    navigation: {
        nextEl: '.swiper__arrow-right',
        prevEl: '.swiper__arrow-left',
    },
    loop: true,
});
var gallerySwiper = new Swiper('.gallery-container', {
    slidesPerView: 4,
    spaceBetween: 20,
    navigation: {
        nextEl: '.gallery__arrow-right',
        prevEl: '.gallery__arrow-left',
    },
    loop: true,
});

ymaps.ready(init);

    function init() {
        var myMap = new ymaps.Map("map", {
            center: [41.257762, 69.313785], // Координаты центра карты
            zoom: 13
        });

        var myPlacemark = new ymaps.Placemark([41.257762, 69.313785], {
            hintContent: 'Моя кастомная метка',
            balloonContent: 'Ташкент, центр'
        }, {
            iconLayout: 'default#image', // Используем кастомное изображение
            iconImageHref: 'https://upload.wikimedia.org/wikipedia/commons/e/ec/RedDot.svg', // Ссылка на картинку
            iconImageSize: [40, 40], // Размер иконки (ширина, высота)
            iconImageOffset: [-20, -20] // Смещение, чтобы центр совпадал с координатами
        });

        myMap.geoObjects.add(myPlacemark);
    }